package xing.utd.com.spectre;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.NetworkOnMainThreadException;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.util.Arrays;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import com.stfalcon.chatkit.*;

public class MainActivity extends FragmentActivity {
    CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        WebView webView = findViewById(R.id.url);
//        WebSettings webSettings = webView.getSettings();
//        webSettings.setJavaScriptEnabled(true);
//        webView.loadUrl("https://www.facebook.com/v2.6/dialog/oauth?redirect_uri=fb464891386855067%3A%2F%2Fauthorize%2F&display=touch&state=%7B%22challenge%22%3A%22IUUkEUqIGud332lfu%252BMJhxL4Wlc%253D%22%2C%220_auth_logger_id%22%3A%2230F06532-A1B9-4B10-BB28-B29956C71AB1%22%2C%22com.facebook.sdk_client_state%22%3Atrue%2C%223_method%22%3A%22sfvc_auth%22%7D&scope=user_birthday%2Cuser_photos%2Cuser_education_history%2Cemail%2Cuser_relationship_details%2Cuser_friends%2Cuser_work_history%2Cuser_likes&response_type=token%2Csigned_request&default_audience=friends&return_scopes=true&auth_type=rerequest&client_id=464891386855067&ret=login&sdk=ios&logger_id=30F06532-A1B9-4B10-BB28-B29956C71AB1&ext=1470840777&hash=AeZqkIcf-NEW6vBd");
//        String username = "yaoxing1990";
//        String password = "567GH@#jgye";
//        GetFacebookToken get = new GetFacebookToken(username, password);
//        get.execute();
//        WebView webView = findViewById(R.id.url);
//        WebSettings webSettings = webView.getSettings();
//        webSettings.setJavaScriptEnabled(true);
//        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
//        String html = "<!DOCTYPE html>\n" +
//                "<html>\n" +
//                "<head>\n" +
//                "<title>Facebook Login JavaScript Example</title>\n" +
//                "<meta charset=\"UTF-8\">\n" +
//                "</head>\n" +
//                "<body>\n" +
//                "<script>\n" +
//                "  // This is called with the results from from FB.getLoginStatus().\n" +
//                "  function statusChangeCallback(response) {\n" +
//                "    console.log('statusChangeCallback');\n" +
//                "    console.log(response);\n" +
//                "    // The response object is returned with a status field that lets the\n" +
//                "    // app know the current login status of the person.\n" +
//                "    // Full docs on the response object can be found in the documentation\n" +
//                "    // for FB.getLoginStatus().\n" +
//                "    if (response.status === 'connected') {\n" +
//                "      // Logged into your app and Facebook.\n" +
//                "      testAPI();\n" +
//                "    } else {\n" +
//                "      // The person is not logged into your app or we are unable to tell.\n" +
//                "      document.getElementById('status').innerHTML = 'Please log ' +\n" +
//                "        'into this app.';\n" +
//                "    }\n" +
//                "  }\n" +
//                "\n" +
//                "  // This function is called when someone finishes with the Login\n" +
//                "  // Button.  See the onlogin handler attached to it in the sample\n" +
//                "  // code below.\n" +
//                "  function checkLoginState() {\n" +
//                "    FB.getLoginStatus(function(response) {\n" +
//                "      statusChangeCallback(response);\n" +
//                "    });\n" +
//                "  }\n" +
//                "\n" +
//                "  window.fbAsyncInit = function() {\n" +
//                "  FB.init({\n" +
//                "    appId      : '{137236810380513}',\n" +
//                "    cookie     : true,  // enable cookies to allow the server to access \n" +
//                "                        // the session\n" +
//                "    xfbml      : true,  // parse social plugins on this page\n" +
//                "    version    : 'v2.8' // use graph api version 2.8\n" +
//                "  });\n" +
//                "\n" +
//                "  // Now that we've initialized the JavaScript SDK, we call \n" +
//                "  // FB.getLoginStatus().  This function gets the state of the\n" +
//                "  // person visiting this page and can return one of three states to\n" +
//                "  // the callback you provide.  They can be:\n" +
//                "  //\n" +
//                "  // 1. Logged into your app ('connected')\n" +
//                "  // 2. Logged into Facebook, but not your app ('not_authorized')\n" +
//                "  // 3. Not logged into Facebook and can't tell if they are logged into\n" +
//                "  //    your app or not.\n" +
//                "  //\n" +
//                "  // These three cases are handled in the callback function.\n" +
//                "\n" +
//                "  FB.getLoginStatus(function(response) {\n" +
//                "    statusChangeCallback(response);\n" +
//                "  });\n" +
//                "\n" +
//                "  };\n" +
//                "\n" +
//                "  // Load the SDK asynchronously\n" +
//                "  (function(d, s, id) {\n" +
//                "    var js, fjs = d.getElementsByTagName(s)[0];\n" +
//                "    if (d.getElementById(id)) return;\n" +
//                "    js = d.createElement(s); js.id = id;\n" +
//                "    js.src = \"https://connect.facebook.net/en_US/sdk.js\";\n" +
//                "    fjs.parentNode.insertBefore(js, fjs);\n" +
//                "  }(document, 'script', 'facebook-jssdk'));\n" +
//                "\n" +
//                "  // Here we run a very simple test of the Graph API after login is\n" +
//                "  // successful.  See statusChangeCallback() for when this call is made.\n" +
//                "  function testAPI() {\n" +
//                "    console.log('Welcome!  Fetching your information.... ');\n" +
//                "    FB.api('/me', function(response) {\n" +
//                "      console.log('Successful login for: ' + response.name);\n" +
//                "      document.getElementById('status').innerHTML =\n" +
//                "        'Thanks for logging in, ' + response.name + '!';\n" +
//                "    });\n" +
//                "  }\n" +
//                "</script>\n" +
//                "\n" +
//                "<!--\n" +
//                "  Below we include the Login Button social plugin. This button uses\n" +
//                "  the JavaScript SDK to present a graphical Login button that triggers\n" +
//                "  the FB.login() function when clicked.\n" +
//                "-->\n" +
//                "\n" +
//                "<fb:login-button scope=\"public_profile,email\" onlogin=\"checkLoginState();\">\n" +
//                "</fb:login-button>\n" +
//                "\n" +
//                "<div id=\"status\">\n" +
//                "</div>\n" +
//                "\n" +
//                "</body>\n" +
//                "</html>";
//        String mime = "text/html";
//        String encoding = "utf-8";
//        webView.loadDataWithBaseURL(null, html, mime, encoding, null);
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        callbackManager = CallbackManager.Factory.create();
        final LoginButton loginButton = findViewById(R.id.login_button);
        loginButton.registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {

                        //The id and token obtained from facebook api is not right
                        final String id = loginResult.getAccessToken().getUserId();
                        final String token = loginResult.getAccessToken().getToken();
                        /*
                        final String id = "";
                        final String token = "";
                        */
                        Authentication auth = new Authentication(id, token);
                        auth.execute();
                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                    }
                });
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

//    public class WebAppInterface {
//        Context mContext;
//
//        /** Instantiate the interface and set the context */
//        WebAppInterface(Context c) {
//            mContext = c;
//        }
//
//        @JavascriptInterface
//        public void showToast(String toast) {
//            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
//        }
//    }

//    class GetFacebookToken extends AsyncTask<String, Void, String> {
//        String username = null;
//        String password = null;
//        String fbId = null;
//        String fbToken = null;
//        Response response = null;
//
//        public GetFacebookToken(String username, String password) {
//            this.username = username;
//            this.password = password;
//        }
//
//        protected String doInBackground(String... urls) {
//            //Get facebook id and token
//            String FB_AUTH = "https://www.facebook.com/v2.6/dialog/oauth?redirect_uri=fb464891386855067%3A%2F%2Fauthorize%2F&display=touch&state=%7B%22challenge%22%3A%22IUUkEUqIGud332lfu%252BMJhxL4Wlc%253D%22%2C%220_auth_logger_id%22%3A%2230F06532-A1B9-4B10-BB28-B29956C71AB1%22%2C%22com.facebook.sdk_client_state%22%3Atrue%2C%223_method%22%3A%22sfvc_auth%22%7D&scope=user_birthday%2Cuser_photos%2Cuser_education_history%2Cemail%2Cuser_relationship_details%2Cuser_friends%2Cuser_work_history%2Cuser_likes&response_type=token%2Csigned_request&default_audience=friends&return_scopes=true&auth_type=rerequest&client_id=464891386855067&ret=login&sdk=ios&logger_id=30F06532-A1B9-4B10-BB28-B29956C71AB1&ext=1470840777&hash=AeZqkIcf-NEW6vBd";
//            OkHttpClient client = new OkHttpClient();
//            Request request = new Request.Builder()
//                    .url(FB_AUTH)
//                    .get()
//                    .addHeader("content-type", "application/json")
//                    .addHeader("pass", password)
//                    .addHeader("email", username)
//                    .build();
//            try {
//                response = client.newCall(request).execute();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            return null;
//        }
//
//        protected void onPostExecute(String feed) {
//            parseFBJSON pj = new parseFBJSON(response);
//            pj.execute();
//        }
//    }
//
//    class parseFBJSON extends AsyncTask<String, Void, String> {
//
//        Response res;
//        String tar = null;
//        String FBToken = null;
//        String FBId = null;
//
//        public parseFBJSON(Response res) {
//            this.res = res;
//        }
//
//        protected String doInBackground(String... urls) {
//            try {
//                tar = res.body().string();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            return tar;
//        }
//
//        protected void onPostExecute(String feed) {
//            JSONParser parser = new JSONParser();
//            try {
//                JSONObject res = (JSONObject) parser.parse(tar);
//                JSONObject user = (JSONObject) parser.parse(res.get("user").toString());
//                FBToken = user.get("api_token").toString();
//                FBId =  user.get("api_token").toString();
//            } catch (ParseException e) {
//                e.printStackTrace();
//            } catch (NetworkOnMainThreadException e) {
//                e.getMessage();
//            }
//
//            if(FBId != null && FBToken != null) {
//                Authentication auth = new Authentication(FBId, FBToken);
//                auth.execute();
//            }
//        }
//    }

    class Authentication extends AsyncTask<String, Void, Response> {

        String id;
        String token;
        Response response = null;

        public Authentication (String id, String token) {
            this.id = id;
            this.token = token;
        }

        protected Response doInBackground(String... urls) {
            OkHttpClient client = new OkHttpClient();
            RequestBody body = null;
            try {
                final MediaType JSON = MediaType.parse("application/json");
                JSONObject json = new JSONObject();
                json.put("facebook_token", token);
                json.put("facebook_id", id);
                String jsonString = json.toString();
                body = RequestBody.create(JSON, jsonString);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Request request = new Request.Builder()
                    .url("https://api.gotinder.com/auth")
                    .post(body)
                    .addHeader("content-type", "application/json")
                    .addHeader("user-agent", "Tinder/7.5.3 (iPhone; iOS 10.3.2; Scale/2.00)")
                    .build();
            try {
                response = client.newCall(request).execute();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        protected void onPostExecute(Response feed) {
            parseJSON pj = new parseJSON(response);
            pj.execute();
        }

    }

    class parseJSON extends AsyncTask<String, Void, String> {

        Response res;
        String tar = null;
        String tinderToken = null;

        public parseJSON(Response res) {
            this.res = res;
        }

        protected String doInBackground(String... urls) {
            try {
                tar = res.body().string();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return tar;
        }

        protected void onPostExecute(String feed) {
            JSONParser parser = new JSONParser();
            try {
                JSONObject res = (JSONObject) parser.parse(tar);
                JSONObject user = (JSONObject) parser.parse(res.get("user").toString());
                tinderToken = user.get("api_token").toString();
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (NetworkOnMainThreadException e) {
                e.getMessage();
            }
            //tinderToken = "520a89a1-939f-43c6-b42d-f7af684e3eb5";
            if(tinderToken != null) {
                GetProfile getProfile = new GetProfile(tinderToken);
                getProfile.execute();
            }
        }
    }

    class GetProfile extends AsyncTask<String, Void, Response> {

        String tinderToken;
        String info = null;
        Response response = null;
        TextView inf = null;

        public GetProfile(String tinderToken) {
            this.tinderToken = tinderToken;
            this.inf = findViewById(R.id.inf);
        }

        protected Response doInBackground(String... urls) {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("https://api.gotinder.com/profile")
                    .get()
                    .addHeader("X-Auth-Token", tinderToken)
                    .addHeader("content-type", "application/json")
                    .addHeader("user-agent", "Tinder/7.5.3 (iPhone; iOS 10.3.2; Scale/2.00)")
                    .build();
            try {
                response = client.newCall(request).execute();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        protected void onPostExecute(Response feed) {
            try {
                info = response.body().string();
                inf.setText(info);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
